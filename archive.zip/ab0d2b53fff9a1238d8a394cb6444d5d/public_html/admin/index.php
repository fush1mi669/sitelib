<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

require __DIR__ . '/../partials/header.php';
?>

<div class="section-title">
  <h2 style="margin:0">Администрирование</h2>
</div>

<div class="grid" style="grid-template-columns:repeat(2, minmax(0,1fr)); margin-top:14px">
  <a class="card card-pad" href="<?= BASE_URL ?>admin/books_create.php">
    <h3>Добавить книгу</h3>
    <p class="muted">Добавление книг в каталог.</p>
  </a>
  <a class="card card-pad" href="<?= BASE_URL ?>admin/readers.php">
    <h3>Управление читателями</h3>
    <p class="muted">Выдача, продление, приём возврата.</p>
  </a>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>

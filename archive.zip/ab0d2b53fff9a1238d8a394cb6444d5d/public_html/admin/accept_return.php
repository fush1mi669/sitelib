<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'admin/readers.php'); exit; }

$pdo = db();
$loanId = (int)($_POST['loan_id'] ?? 0);

$stmt = $pdo->prepare("SELECT id FROM loans WHERE id=:id AND returned_at IS NULL LIMIT 1");
$stmt->execute([':id'=>$loanId]);
$loan = $stmt->fetch();

if (!$loan) {
  flash_set('err','Выдача не найдена.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

$pdo->prepare("UPDATE loans SET returned_at=NOW(), status='returned' WHERE id=:id")->execute([':id'=>$loanId]);
flash_set('ok','Книга принята.');
header('Location: ' . BASE_URL . 'admin/readers.php');
exit;
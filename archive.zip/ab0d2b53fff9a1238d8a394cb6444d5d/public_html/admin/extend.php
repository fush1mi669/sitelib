<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'admin/readers.php'); exit; }

$pdo = db();
$loanId = (int)($_POST['loan_id'] ?? 0);
$days = (int)($_POST['days'] ?? 7);
if ($days < 1) $days = 1;
if ($days > 60) $days = 60;

$stmt = $pdo->prepare("SELECT id, user_id FROM loans WHERE id=:id AND returned_at IS NULL LIMIT 1");
$stmt->execute([':id'=>$loanId]);
$loan = $stmt->fetch();

if (!$loan) {
  flash_set('err','Выдача не найдена.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

$pdo->prepare("
  UPDATE loans
  SET due_at = DATE_ADD(due_at, INTERVAL :d DAY),
      extensions_count = extensions_count + 1
  WHERE id=:id
")->execute([':d'=>$days, ':id'=>$loanId]);

flash_set('ok','Срок продлён.');
header('Location: ' . BASE_URL . 'admin/readers.php?user='.(int)$loan['user_id'].'#loans');

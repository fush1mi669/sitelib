<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'admin/readers.php'); exit; }

$pdo = db();
$requestId = (int)($_POST['request_id'] ?? 0);
$reject = (int)($_POST['reject'] ?? 0) === 1;

$stmt = $pdo->prepare("
  SELECT br.*, b.id book_id
  FROM book_requests br
  JOIN books b ON b.id=br.book_id
  WHERE br.id=:rid
  LIMIT 1
");
$stmt->execute([':rid'=>$requestId]);
$req = $stmt->fetch();

if (!$req || $req['status'] !== 'pending') {
  flash_set('err','Заявка не найдена или уже обработана.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

if ($reject) {
  $pdo->prepare("UPDATE book_requests SET status='rejected' WHERE id=:rid")->execute([':rid'=>$requestId]);
  flash_set('ok','Заявка отклонена.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

// ensure availability
if (!book_is_available((int)$req['book_id'])) {
  flash_set('err','Книга уже выдана другому читателю.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

// issue for 14 days default
$due = (new DateTimeImmutable('now'))->modify('+14 days')->format('Y-m-d H:i:s');

$pdo->beginTransaction();
try {
  $pdo->prepare("UPDATE book_requests SET status='approved' WHERE id=:rid")->execute([':rid'=>$requestId]);
  $stmt2 = $pdo->prepare("INSERT INTO loans(user_id, book_id, request_id, issued_at, due_at, status) VALUES (:uid,:bid,:rid,NOW(),:due,'issued')");
  $stmt2->execute([':uid'=>$req['user_id'], ':bid'=>$req['book_id'], ':rid'=>$requestId, ':due'=>$due]);
  $pdo->commit();
} catch (Throwable $e) {
  $pdo->rollBack();
  flash_set('err','Ошибка выдачи.');
  header('Location: ' . BASE_URL . 'admin/readers.php'); exit;
}

flash_set('ok','Книга выдана.');
header('Location: ' . BASE_URL . 'admin/readers.php?user='.(int)$req['user_id'].'#loans');

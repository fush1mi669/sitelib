<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

$pdo = db();

$pending = $pdo->query("
  SELECT br.id request_id, br.created_at, u.id user_id, u.full_name, u.email,
         b.id book_id, b.title, b.author, b.isbn
  FROM book_requests br
  JOIN users u ON u.id=br.user_id
  JOIN books b ON b.id=br.book_id
  WHERE br.status='pending'
  ORDER BY br.created_at ASC
")->fetchAll();

$readers = $pdo->query("
  SELECT u.id, u.full_name, u.email,
    (SELECT COUNT(*) FROM loans l WHERE l.user_id=u.id AND l.returned_at IS NULL) active_count,
    (SELECT COUNT(*) FROM loans l WHERE l.user_id=u.id AND l.returned_at IS NULL AND l.due_at < NOW()) overdue_count
  FROM users u
  JOIN roles r ON r.id=u.role_id
  WHERE r.code='reader'
  ORDER BY u.full_name
")->fetchAll();

$loansRows = $pdo->query("
  SELECT
    l.id AS loan_id,
    l.user_id,
    l.issued_at,
    l.due_at,
    l.returned_at,
    b.title,
    b.author,
    b.isbn
  FROM loans l
  JOIN books b ON b.id = l.book_id
  ORDER BY l.user_id, l.issued_at DESC
")->fetchAll();

$loansByUser = [];
foreach ($loansRows as $lr) {
  $loansByUser[(int)$lr['user_id']][] = $lr;
}

require __DIR__ . '/../partials/header.php';
?>

<div class="section-title">
  <h2 style="margin:0">Управление читателями</h2>
  <a class="btn btn-secondary" href="<?= BASE_URL ?>admin/index.php">Назад</a>
</div>

<h3 style="margin-top:14px">Заявки на выдачу</h3>
<div class="table-wrap" style="margin-top:10px">
  <table class="table">
    <thead>
      <tr>
        <th>Дата</th>
        <th>Читатель</th>
        <th>Книга</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$pending): ?>
        <tr><td colspan="4" class="muted">Нет заявок.</td></tr>
      <?php endif; ?>
      <?php foreach($pending as $p): ?>
        <tr>
          <td><?= e(date('d.m.Y H:i', strtotime($p['created_at']))) ?></td>
          <td>
            <strong><?= e($p['full_name']) ?></strong><br/>
            <span class="muted small"><?= e($p['email']) ?></span>
          </td>
          <td>
            <strong><?= e($p['title']) ?></strong><br/>
            <span class="muted small"><?= e($p['author']) ?> · ISBN <?= e($p['isbn']) ?></span>
          </td>
          <td style="white-space:nowrap">
            <form method="post" action="<?= BASE_URL ?>admin/issue.php" style="margin:0; display:inline">
              <input type="hidden" name="request_id" value="<?= (int)$p['request_id'] ?>"/>
              <button class="btn btn-ok" type="submit">Выдать</button>
            </form>
            <form method="post" action="<?= BASE_URL ?>admin/issue.php" style="margin:0; display:inline">
              <input type="hidden" name="request_id" value="<?= (int)$p['request_id'] ?>"/>
              <input type="hidden" name="reject" value="1"/>
              <button class="btn btn-danger" type="submit">Отклонить</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<h3 style="margin-top:18px">Читатели</h3>
<div class="table-wrap" style="margin-top:10px">
  <table class="table">
    <thead>
      <tr>
        <th>Читатель</th>
        <th>Активные</th>
        <th>Просрочено</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($readers as $r): ?>
        <?php $uid = (int)$r['id']; $userLoans = $loansByUser[$uid] ?? []; ?>
        <tr>
          <td>
            <strong><?= e($r['full_name']) ?></strong><br/>
            <span class="muted small"><?= e($r['email']) ?></span>
          </td>
          <td><?= (int)$r['active_count'] ?></td>
          <td><?= (int)$r['overdue_count'] ?></td>
        </tr>
        <tr>
          <td colspan="3">
            <div style="padding:10px 0">
              <div class="muted" style="margin-bottom:8px">Книги читателя:</div>

              <?php if (!$userLoans): ?>
                <div class="muted">Выдач нет.</div>
              <?php else: ?>
                <div class="table-wrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Книга</th>
                        <th>Выдана</th>
                        <th>Срок</th>
                        <th>Статус</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($userLoans as $l): ?>
                        <tr>
                          <td>
                            <strong><?= e($l['title']) ?></strong><br/>
                            <span class="muted small"><?= e($l['author']) ?> · ISBN <?= e($l['isbn']) ?></span>
                          </td>
                          <td><?= e(date('d.m.Y H:i', strtotime($l['issued_at']))) ?></td>
                          <td><?= e(date('d.m.Y H:i', strtotime($l['due_at']))) ?></td>
                          <td><?= empty($l['returned_at']) ? 'Активна' : 'Возвращена' ?></td>
                          <td style="white-space:nowrap">
                            <?php if (empty($l['returned_at'])): ?>
                              <form method="post" action="<?= BASE_URL ?>admin/accept_return.php" style="margin:0">
                                <input type="hidden" name="loan_id" value="<?= (int)$l['loan_id'] ?>">
                                <button class="btn btn-ok" type="submit">Принять возврат</button>
                              </form>
                            <?php else: ?>
                              <span class="muted">—</span>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
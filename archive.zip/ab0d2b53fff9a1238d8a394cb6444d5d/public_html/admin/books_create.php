<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_admin();

$pdo = db();
$genres = $pdo->query("SELECT id,name FROM genres ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = trim($_POST['title'] ?? '');
  $author = trim($_POST['author'] ?? '');
  $isbn = trim($_POST['isbn'] ?? '');
  $genre_id = (int)($_POST['genre_id'] ?? 0);
  $new_genre = trim($_POST['new_genre'] ?? '');

  if ($new_genre !== '') {
    try {
      $stmt = $pdo->prepare("INSERT INTO genres(name) VALUES(:n)");
      $stmt->execute([':n'=>$new_genre]);
      $genre_id = (int)$pdo->lastInsertId();
    } catch (PDOException $e) {
      // ignore duplicates
      $stmt = $pdo->prepare("SELECT id FROM genres WHERE name=:n");
      $stmt->execute([':n'=>$new_genre]);
      $genre_id = (int)$stmt->fetchColumn();
    }
  }

  if ($title==='' || $author==='' || $isbn==='') {
    flash_set('err','Заполните название, автора и ISBN.');
    header('Location: ' . BASE_URL . 'admin/books_create.php'); exit;
  }

  $coverName = null;
  if (!empty($_FILES['cover']['name'])) {
    $ext = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION);
    $safe = bin2hex(random_bytes(8)) . '.' . strtolower($ext);
    $dest = __DIR__ . '/../uploads/' . $safe;
    if (move_uploaded_file($_FILES['cover']['tmp_name'], $dest)) {
      $coverName = $safe;
    }
  }

  try {
    $stmt = $pdo->prepare("INSERT INTO books(title,author,isbn,genre_id,cover_path,is_active) VALUES (:t,:a,:i,:g,:c,1)");
    $stmt->execute([
      ':t'=>$title, ':a'=>$author, ':i'=>$isbn,
      ':g'=>($genre_id>0 ? $genre_id : null),
      ':c'=>$coverName
    ]);
  } catch (PDOException $e) {
    flash_set('err','Не удалось добавить книгу (возможно, ISBN уже существует).');
    header('Location: ' . BASE_URL . 'admin/books_create.php'); exit;
  }

  flash_set('ok','Книга добавлена.');
  header('Location: ' . BASE_URL . 'index.php'); exit;
}

require __DIR__ . '/../partials/header.php';
?>

<div class="section-title">
  <h2 style="margin:0">Добавить книгу</h2>
  <a class="btn btn-secondary" href="<?= BASE_URL ?>admin/index.php">Назад</a>
</div>

<form method="post" enctype="multipart/form-data" class="card card-pad" style="margin-top:14px">
  <div class="row">
    <div class="field">
      <label class="muted">Название</label>
      <input class="input" name="title" required/>
    </div>
    <div class="field">
      <label class="muted">Автор</label>
      <input class="input" name="author" required/>
    </div>
  </div>
  <div class="row" style="margin-top:10px">
    <div class="field">
      <label class="muted">ISBN</label>
      <input class="input" name="isbn" required/>
    </div>
    <div class="field">
      <label class="muted">Жанр</label>
      <select name="genre_id">
        <option value="0">—</option>
        <?php foreach($genres as $g): ?>
          <option value="<?= (int)$g['id'] ?>"><?= e($g['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <div class="muted small" style="margin-top:6px">или новый жанр:</div>
      <input class="input" name="new_genre" placeholder="Например: Фантастика"/>
    </div>
  </div>
  <div class="row" style="margin-top:10px">
    <div class="field">
      <label class="muted">Обложка</label>
      <input class="input" type="file" name="cover" accept="image/*"/>
      <div class="muted small" style="margin-top:6px">Если не загрузить, будет заглушка.</div>
    </div>
  </div>
  <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap">
    <button class="btn" type="submit">Сохранить</button>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>index.php">Каталог</a>
  </div>
</form>

<?php require __DIR__ . '/../partials/footer.php'; ?>

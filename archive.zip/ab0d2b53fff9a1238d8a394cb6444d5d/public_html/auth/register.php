<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'index.php'); exit; }

$full = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$p1 = (string)($_POST['password'] ?? '');
$p2 = (string)($_POST['password2'] ?? '');

if (mb_strlen($full) < 3) {
  flash_set('err', 'ФИО слишком короткое.');
  header('Location: ' . BASE_URL . 'index.php?register=1'); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  flash_set('err', 'Некорректный email.');
  header('Location: ' . BASE_URL . 'index.php?register=1'); exit;
}
if (strlen($p1) < 6) {
  flash_set('err', 'Пароль должен быть не короче 6 символов.');
  header('Location: ' . BASE_URL . 'index.php?register=1'); exit;
}
if ($p1 !== $p2) {
  flash_set('err', 'Пароли не совпадают.');
  header('Location: ' . BASE_URL . 'index.php?register=1'); exit;
}

$pdo = db();
$roleId = (int)$pdo->query("SELECT id FROM roles WHERE code='reader'")->fetchColumn();

try {
  $stmt = $pdo->prepare("INSERT INTO users(role_id, full_name, email, password_hash) VALUES (:rid,:full,:email,:hash)");
  $stmt->execute([
    ':rid' => $roleId,
    ':full' => $full,
    ':email' => $email,
    ':hash' => password_hash($p1, PASSWORD_DEFAULT),
  ]);
} catch (PDOException $e) {
  flash_set('err', 'Такой email уже зарегистрирован.');
  header('Location: ' . BASE_URL . 'index.php?register=1'); exit;
}

flash_set('ok', 'Регистрация успешна. Теперь войдите.');
header('Location: ' . BASE_URL . 'index.php?login=1');

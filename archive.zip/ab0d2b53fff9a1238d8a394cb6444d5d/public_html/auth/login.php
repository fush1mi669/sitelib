<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'index.php'); exit; }

$email = trim($_POST['email'] ?? '');
$pass  = (string)($_POST['password'] ?? '');

if ($email === '' || $pass === '') {
  flash_set('err', 'Заполните email и пароль.');
  header('Location: ' . BASE_URL . 'index.php?login=1');
  exit;
}

$pdo = db();
$stmt = $pdo->prepare("
  SELECT u.id, u.full_name, u.email, u.password_hash, r.code role
  FROM users u
  JOIN roles r ON r.id = u.role_id
  WHERE u.email = :email
  LIMIT 1
");
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($pass, $user['password_hash'])) {
  flash_set('err', 'Неверный email или пароль.');
  header('Location: ' . BASE_URL . 'index.php?login=1');
  exit;
}

$_SESSION['user_id'] = (int)$user['id'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['email'] = $user['email'];
$_SESSION['role'] = $user['role'];

flash_set('ok', 'Вы вошли в аккаунт.');
header('Location: ' . BASE_URL . 'index.php');

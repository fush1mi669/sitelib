<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

$q = trim($_GET['q'] ?? '');

$pdo = db();
$params = [];
$where = "WHERE b.is_active=1";
if ($q !== '') {
  $where .= " AND (b.title LIKE :q OR b.author LIKE :q OR b.isbn LIKE :q)";
  $params[':q'] = "%$q%";
}
$sql = "
SELECT b.*, g.name genre
FROM books b
LEFT JOIN genres g ON g.id=b.genre_id
$where
ORDER BY b.created_at DESC
LIMIT 200
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

require __DIR__ . '/partials/header.php';
?>

<div class="section-title">
  <h2 style="margin:0">Каталог</h2>
</div>

<div class="toolbar">
  <form method="get" class="row" style="width:100%">
    <div class="field">
      <input class="input" name="q" placeholder="Быстрый поиск: название, автор или ISBN" value="<?= e($q) ?>"/>
    </div>
    <button class="btn" type="submit">Найти</button>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>advanced_search.php">Расширенный поиск</a>
  </form>
</div>

<div class="grid books">
<?php foreach($books as $b): 
  $available = book_is_available((int)$b['id']);
  $cover = $b['cover_path'] ? BASE_URL . 'uploads/' . $b['cover_path'] : BASE_URL . 'assets/img/logo.svg';
?>
  <div class="card">
    <img class="cover" src="<?= e($cover) ?>" alt="cover"/>
    <div class="card-pad">
      <h3><?= e($b['title']) ?></h3>
      <div class="muted"><?= e($b['author']) ?></div>
      <div class="kv">
        <?php if (!empty($b['genre'])): ?><span class="tag"><?= e($b['genre']) ?></span><?php endif; ?>
        <span class="tag">ISBN: <?= e($b['isbn']) ?></span>
        <span class="tag"><?= $available ? 'Доступна' : 'Выдана' ?></span>
      </div>

      <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap">
        <?php if ($available): ?>
          <?php if (is_logged_in()): ?>
            <form method="post" action="<?= BASE_URL ?>requests/create.php" style="margin:0">
              <input type="hidden" name="book_id" value="<?= (int)$b['id'] ?>"/>
              <button class="btn btn-ok" type="submit">Взять книгу</button>
            </form>
          <?php else: ?>
            <button class="btn" type="button" onclick="openModal('loginModal')">Войти, чтобы взять</button>
          <?php endif; ?>
        <?php else: ?>
          <button class="btn btn-secondary" type="button" disabled>Недоступна</button>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>

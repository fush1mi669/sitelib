<?php
declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'fush1mg3_lib');
define('DB_USER', 'fush1mg3_lib');
define('DB_PASS', 'Lib123_');

define('BASE_URL', '/');
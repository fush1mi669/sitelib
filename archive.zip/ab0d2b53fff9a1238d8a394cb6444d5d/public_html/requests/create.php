<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . 'index.php'); exit; }

$user = current_user();
$bookId = (int)($_POST['book_id'] ?? 0);

if ($bookId <= 0) { flash_set('err','Некорректная книга.'); header('Location: ' . BASE_URL . 'index.php'); exit; }

if (!book_is_available($bookId)) {
  flash_set('err','Книга уже выдана.');
  header('Location: ' . BASE_URL . 'index.php'); exit;
}

$pdo = db();
// prevent duplicate pending
$stmt = $pdo->prepare("SELECT COUNT(*) c FROM book_requests WHERE user_id=:uid AND book_id=:bid AND status='pending'");
$stmt->execute([':uid'=>$user['id'], ':bid'=>$bookId]);
if ((int)$stmt->fetch()['c'] > 0) {
  flash_set('err','Заявка на эту книгу уже отправлена.');
  header('Location: ' . BASE_URL . 'index.php'); exit;
}

$stmt = $pdo->prepare("INSERT INTO book_requests(user_id, book_id, status) VALUES (:uid,:bid,'pending')");
$stmt->execute([':uid'=>$user['id'], ':bid'=>$bookId]);

flash_set('ok','Заявка отправлена администратору.');
header('Location: ' . BASE_URL . 'index.php');

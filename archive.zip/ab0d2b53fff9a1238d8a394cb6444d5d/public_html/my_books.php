<?php
require_once __DIR__ . '/helpers.php';
require_login();

$user = current_user();
$pdo = db();

$stmt = $pdo->prepare("
    SELECT l.*, b.title, b.author
    FROM loans l
    JOIN books b ON b.id = l.book_id
    WHERE l.user_id = :uid
    ORDER BY l.issued_at DESC
");
$stmt->execute([':uid' => $user['id']]);
$books = $stmt->fetchAll();

require __DIR__ . '/partials/header.php';
?>

<h2>Мои книги</h2>

<?php if (!$books): ?>
    <p class="muted">У вас пока нет выданных книг.</p>
<?php else: ?>

<div style="overflow:auto;">
<table class="table">
    <thead>
        <tr>
            <th>Название</th>
            <th>Автор</th>
            <th>Дата выдачи</th>
            <th>Срок возврата</th>
            <th>Статус</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($books as $b): ?>
        <?php
        $isOverdue = !$b['returned_at'] && strtotime($b['due_at']) < time();
        ?>
        <tr>
            <td><?= e($b['title']) ?></td>
            <td><?= e($b['author']) ?></td>
            <td><?= e($b['issued_at']) ?></td>
            <td><?= e($b['due_at']) ?></td>
            <td>
                <?php if ($b['returned_at']): ?>
                    Возвращена
                <?php elseif ($isOverdue): ?>
                    <span style="color:#ff4d6d;">Просрочена</span>
                <?php else: ?>
                    Выдана
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
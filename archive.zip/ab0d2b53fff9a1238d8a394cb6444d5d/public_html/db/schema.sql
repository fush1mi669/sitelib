-- MySQL / MariaDB schema for Library app
CREATE DATABASE IF NOT EXISTS library_app
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;
USE library_app;

CREATE TABLE roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(64) NOT NULL
);

INSERT INTO roles(code, name) VALUES
('reader','Читатель'),
('admin','Администратор');

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  full_name VARCHAR(128) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE genres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(64) NOT NULL UNIQUE
);

CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  isbn VARCHAR(32) NOT NULL UNIQUE,
  genre_id INT NULL,
  cover_path VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (genre_id) REFERENCES genres(id)
);

CREATE TABLE book_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  status ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE loans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  request_id INT NULL,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  due_at DATETIME NOT NULL,
  returned_at DATETIME NULL,
  extensions_count INT NOT NULL DEFAULT 0,
  status ENUM('issued','returned','overdue') NOT NULL DEFAULT 'issued',
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (book_id) REFERENCES books(id),
  FOREIGN KEY (request_id) REFERENCES book_requests(id)
);

CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_books_author ON books(author);
CREATE INDEX idx_loans_user_status ON loans(user_id, status);

-- Seed data (optional)
INSERT INTO genres(name) VALUES ('Фантастика'),('Детектив'),('Классика') ON DUPLICATE KEY UPDATE name=name;

INSERT INTO books(title,author,isbn,genre_id,is_active)
VALUES
('Пикник на обочине','Аркадий и Борис Стругацкие','9785170906300',(SELECT id FROM genres WHERE name='Фантастика'),1),
('Шерлок Холмс: Собрание','Артур Конан Дойл','9785389051516',(SELECT id FROM genres WHERE name='Детектив'),1),
('Преступление и наказание','Ф. М. Достоевский','9785171183663',(SELECT id FROM genres WHERE name='Классика'),1);

<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function is_logged_in(): bool { return !empty($_SESSION['user_id']); }

function current_user(): ?array {
  if (!is_logged_in()) return null;
  return [
    'id' => (int)$_SESSION['user_id'],
    'role' => $_SESSION['role'] ?? 'reader',
    'name' => $_SESSION['full_name'] ?? '',
    'email' => $_SESSION['email'] ?? ''
  ];
}

function require_login(): void {
  if (!is_logged_in()) {
    header('Location: ' . BASE_URL . 'index.php?login=1');
    exit;
  }
}

function require_admin(): void {
  require_login();
  if (($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo "Доступ запрещён";
    exit;
  }
}

function flash_set(string $type, string $msg): void {
  $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function flash_get(): ?array {
  if (empty($_SESSION['flash'])) return null;
  $f = $_SESSION['flash'];
  unset($_SESSION['flash']);
  return $f;
}

function overdue_count(int $userId): int {
  $pdo = db();
  $stmt = $pdo->prepare("SELECT COUNT(*) c FROM loans WHERE user_id=:uid AND returned_at IS NULL AND due_at < NOW()");
  $stmt->execute([':uid' => $userId]);
  return (int)$stmt->fetch()['c'];
}

function book_is_available(int $bookId): bool {
  $pdo = db();
  $stmt = $pdo->prepare("SELECT COUNT(*) c FROM loans WHERE book_id=:bid AND returned_at IS NULL AND status IN ('issued','overdue')");
  $stmt->execute([':bid' => $bookId]);
  return ((int)$stmt->fetch()['c']) === 0;
}

function ensure_tables_exist_hint(): void {
  // no-op; keeps place for README
}

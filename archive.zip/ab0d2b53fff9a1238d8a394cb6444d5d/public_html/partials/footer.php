</main>
<footer class="container muted" style="padding-bottom:26px">
  <div style="margin-top:18px; border-top:1px solid rgba(255,255,255,.08); padding-top:14px">
    Библиотека · Учебный проект на PHP + MySQL
  </div>
</footer>
</body>
</html>

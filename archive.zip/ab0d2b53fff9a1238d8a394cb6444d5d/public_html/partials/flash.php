<?php
$f = flash_get();
if (!$f) return;
$typeClass = $f['type'] === 'ok' ? 'ok' : 'err';
?>
<div class="flash <?= e($typeClass) ?>">
  <?= e($f['msg']) ?>
</div>

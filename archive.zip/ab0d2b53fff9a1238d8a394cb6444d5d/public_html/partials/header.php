<?php
require_once __DIR__ . '/../helpers.php';
$user = current_user();
$overdue = $user ? overdue_count($user['id']) : 0;

$showLogin = isset($_GET['login']) && $_GET['login'] == '1';
$showRegister = isset($_GET['register']) && $_GET['register'] == '1';
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Библиотека</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css"/>
</head>
<body>
<header class="header">
  <div class="container">
    <div class="nav">
      <a class="brand" href="<?= BASE_URL ?>index.php">
        <span class="brand-badge">
          <img src="<?= BASE_URL ?>assets/img/logo.svg" alt="logo" width="22" height="22"/>
        </span>
        <span>Библиотека</span>
      </a>

      <!-- Desktop nav -->
      <nav class="nav-links" aria-label="Навигация">
        <a class="pill" href="<?= BASE_URL ?>index.php">Каталог</a>
        <a class="pill" href="<?= BASE_URL ?>advanced_search.php">Поиск</a>

        <?php if ($user): ?>
          <a class="pill" href="<?= BASE_URL ?>my_books.php">
            Мои книги
            <?php if ($overdue > 0): ?><span class="badge"><?= (int)$overdue ?></span><?php endif; ?>
          </a>
          <?php if ($user['role'] === 'admin'): ?>
            <a class="pill" href="<?= BASE_URL ?>admin/index.php">Админ</a>
          <?php endif; ?>
          <a class="pill" href="<?= BASE_URL ?>auth/logout.php">Выйти</a>
        <?php else: ?>
          <button class="btn btn-secondary" type="button" onclick="openModal('loginModal')">Войти</button>
          <button class="btn" type="button" onclick="openModal('registerModal')">Регистрация</button>
        <?php endif; ?>
      </nav>

      <!-- Mobile burger -->
      <button class="burger" type="button" aria-label="Открыть меню" onclick="openDrawer()">
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  </div>
</header>

<!-- Mobile drawer -->
<div class="mobile-drawer-backdrop" id="drawer" onclick="backdropClose(event)">
  <div class="mobile-drawer" role="dialog" aria-modal="true" aria-label="Меню">
    <div class="drawer-head">
      <strong>Меню</strong>
      <button class="x" onclick="closeDrawer()" aria-label="Close">×</button>
    </div>

    <div class="drawer-links">
      <a class="pill" href="<?= BASE_URL ?>index.php">Каталог</a>
      <a class="pill" href="<?= BASE_URL ?>advanced_search.php">Поиск</a>

      <?php if ($user): ?>
        <a class="pill" href="<?= BASE_URL ?>my_books.php">
          Мои книги
          <?php if ($overdue > 0): ?><span class="badge"><?= (int)$overdue ?></span><?php endif; ?>
        </a>
        <?php if ($user['role'] === 'admin'): ?>
          <a class="pill" href="<?= BASE_URL ?>admin/index.php">Админ</a>
        <?php endif; ?>
        <a class="pill" href="<?= BASE_URL ?>auth/logout.php">Выйти</a>
      <?php else: ?>
        <button class="btn btn-secondary" type="button" onclick="closeDrawer(); openModal('loginModal')">Войти</button>
        <button class="btn" type="button" onclick="closeDrawer(); openModal('registerModal')">Регистрация</button>
      <?php endif; ?>
    </div>
  </div>
</div>

<main class="container">
<?php require __DIR__ . '/flash.php'; ?>

<!-- Login modal -->
<div class="modal-backdrop" id="loginModal" style="<?= $showLogin ? 'display:flex' : '' ?>">
  <div class="modal" role="dialog" aria-modal="true" aria-label="Авторизация">
    <div class="modal-header">
      <strong>Вход</strong>
      <button class="x" onclick="closeModal('loginModal')" aria-label="Close">×</button>
    </div>
    <form method="post" action="<?= BASE_URL ?>auth/login.php">
      <div class="modal-body">
        <div class="row">
          <div class="field">
            <label class="muted">Email</label>
            <input class="input" name="email" type="email" required/>
          </div>
        </div>
        <div class="row" style="margin-top:10px">
          <div class="field">
            <label class="muted">Пароль</label>
            <input class="input" name="password" type="password" required/>
          </div>
        </div>
        <p class="muted" style="margin:12px 0 0">
          Нет аккаунта? <a href="javascript:void(0)" onclick="closeModal('loginModal'); openModal('registerModal')"><u>Зарегистрироваться</u></a>
        </p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" onclick="closeModal('loginModal')">Отмена</button>
        <button class="btn" type="submit">Войти</button>
      </div>
    </form>
  </div>
</div>

<!-- Register modal -->
<div class="modal-backdrop" id="registerModal" style="<?= $showRegister ? 'display:flex' : '' ?>">
  <div class="modal" role="dialog" aria-modal="true" aria-label="Регистрация">
    <div class="modal-header">
      <strong>Регистрация</strong>
      <button class="x" onclick="closeModal('registerModal')" aria-label="Close">×</button>
    </div>
    <form method="post" action="<?= BASE_URL ?>auth/register.php">
      <div class="modal-body">
        <div class="row">
          <div class="field">
            <label class="muted">ФИО</label>
            <input class="input" name="full_name" type="text" minlength="3" required/>
          </div>
        </div>
        <div class="row" style="margin-top:10px">
          <div class="field">
            <label class="muted">Email</label>
            <input class="input" name="email" type="email" required/>
          </div>
        </div>
        <div class="row" style="margin-top:10px">
          <div class="field">
            <label class="muted">Пароль</label>
            <input class="input" name="password" type="password" minlength="6" required/>
          </div>
          <div class="field">
            <label class="muted">Повтор пароля</label>
            <input class="input" name="password2" type="password" minlength="6" required/>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" onclick="closeModal('registerModal')">Отмена</button>
        <button class="btn" type="submit">Создать аккаунт</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).style.display='flex'; }
function closeModal(id){ document.getElementById(id).style.display='none'; }

function openDrawer(){
  document.getElementById('drawer').style.display='block';
  document.body.style.overflow='hidden';
}
function closeDrawer(){
  document.getElementById('drawer').style.display='none';
  document.body.style.overflow='';
}
function backdropClose(e){
  if (e.target && e.target.id === 'drawer') closeDrawer();
}

window.addEventListener('keydown', (e)=>{
  if(e.key==='Escape'){
    ['loginModal','registerModal'].forEach(closeModal);
    closeDrawer();
  }
});
</script>

<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

$title = trim($_GET['title'] ?? '');
$author = trim($_GET['author'] ?? '');
$isbn = trim($_GET['isbn'] ?? '');
$genre_id = (int)($_GET['genre_id'] ?? 0);

$pdo = db();
$genres = $pdo->query("SELECT id, name FROM genres ORDER BY name")->fetchAll();

$where = "WHERE b.is_active=1";
$params = [];
if ($title !== '') { $where .= " AND b.title LIKE :title"; $params[':title'] = "%$title%"; }
if ($author !== '') { $where .= " AND b.author LIKE :author"; $params[':author'] = "%$author%"; }
if ($isbn !== '') { $where .= " AND b.isbn LIKE :isbn"; $params[':isbn'] = "%$isbn%"; }
if ($genre_id > 0) { $where .= " AND b.genre_id = :gid"; $params[':gid'] = $genre_id; }

$stmt = $pdo->prepare("
  SELECT b.*, g.name genre
  FROM books b
  LEFT JOIN genres g ON g.id=b.genre_id
  $where
  ORDER BY b.created_at DESC
  LIMIT 200
");
$stmt->execute($params);
$books = $stmt->fetchAll();

require __DIR__ . '/partials/header.php';
?>

<div class="section-title">
  <h2 style="margin:0">Расширенный поиск</h2>
</div>

<form method="get" class="card card-pad" style="margin-top:14px">
  <div class="row">
    <div class="field">
      <label class="muted">Название</label>
      <input class="input" name="title" value="<?= e($title) ?>"/>
    </div>
    <div class="field">
      <label class="muted">Автор</label>
      <input class="input" name="author" value="<?= e($author) ?>"/>
    </div>
  </div>
  <div class="row" style="margin-top:10px">
    <div class="field">
      <label class="muted">ISBN</label>
      <input class="input" name="isbn" value="<?= e($isbn) ?>"/>
    </div>
    <div class="field">
      <label class="muted">Жанр</label>
      <select name="genre_id">
        <option value="0">Любой</option>
        <?php foreach($genres as $g): ?>
          <option value="<?= (int)$g['id'] ?>" <?= $genre_id===(int)$g['id'] ? 'selected' : '' ?>>
            <?= e($g['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap">
    <button class="btn" type="submit">Искать</button>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>advanced_search.php">Сбросить</a>
  </div>
</form>

<div class="section-title">
  <h2 style="margin:18px 0 0">Результаты</h2>
</div>

<div class="grid books" style="margin-top:14px">
<?php foreach($books as $b): 
  $available = book_is_available((int)$b['id']);
  $cover = $b['cover_path'] ? BASE_URL . 'uploads/' . $b['cover_path'] : BASE_URL . 'assets/img/logo.svg';
?>
  <div class="card">
    <img class="cover" src="<?= e($cover) ?>" alt="cover"/>
    <div class="card-pad">
      <h3><?= e($b['title']) ?></h3>
      <div class="muted"><?= e($b['author']) ?></div>
      <div class="kv">
        <?php if (!empty($b['genre'])): ?><span class="tag"><?= e($b['genre']) ?></span><?php endif; ?>
        <span class="tag">ISBN: <?= e($b['isbn']) ?></span>
        <span class="tag"><?= $available ? 'Доступна' : 'Выдана' ?></span>
      </div>

      <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap">
        <?php if ($available): ?>
          <?php if (is_logged_in()): ?>
            <form method="post" action="<?= BASE_URL ?>requests/create.php" style="margin:0">
              <input type="hidden" name="book_id" value="<?= (int)$b['id'] ?>"/>
              <button class="btn btn-ok" type="submit">Взять книгу</button>
            </form>
          <?php else: ?>
            <button class="btn" type="button" onclick="openModal('loginModal')">Войти, чтобы взять</button>
          <?php endif; ?>
        <?php else: ?>
          <button class="btn btn-secondary" type="button" disabled>Недоступна</button>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
